fen.new <- function (fenstr) {
	mv='w'
	if (grepl(' b',fenstr)) {
		mv='black'
	}
	# cleanup if complete string given
	fenstr=gsub(" .+","",fenstr)
	pos=list(fen=fenstr,move=mv)
	class(pos)='fen'
	return(pos)
}

plot.fen <- function (x,cols=c("beige","burlywood"),...) {
	if (class(x)=="character") {
		plot(fen.new(x))
	} else {
		imgdir = file.path(system.file(package="dchess"),'img','wikipedia')
		fstr=x$fen
		for (x in 1:8) {
			fstr=gsub(x, paste(rep(' ',x),collapse=''),fstr)
		}
		fstr=gsub('/','',fstr)
		cols=rep(c(rep(c(cols[2],cols[1]),4),
		rep(c(cols[1],cols[2]),4)),4)
		k=1
		graphics::plot(1,type='n',xlab='',ylab='',
			xlim=c(0,8),ylim=c(0,8),axes=FALSE)
		axis(1)
		axis(2)
		#print(x)
		# update move , protect if plot.fen was called directly
		if (any(names(x) %in% 'move') && x$move=="b") {
			mtext(side=4,at=7.5,text=bquote("\U26AB"),cex=2)
		} else {
			mtext(side=4,at=0.5,text=bquote("\U26AA"),cex=2)
		}
		for (i in 0:7) {
			for (j in 0:7) {
				rect(i,j,i+1,j+1,col=cols[k])
				k=k+1
			}
		}    
		for (i in 0:7) {
			for (j in 0:7) {
				idx=64-8*(i+1)+j+1
				piece=substr(fstr,idx,idx)
				if (piece != ' ') {
					if (grepl('[A-Z]',piece)) {
						col='w'  
					} else { 
						col='b' 
					}
					imgfile=file.path(imgdir,paste(col,toupper(piece),'.png',sep=''))
					pic <- png::readPNG(imgfile)
					graphics::rasterImage(pic, xleft = j+0.1, 
						ybottom = i+0.1, 
						xright=j+0.9,ytop=i+0.9)
				}
			}
		}	
	}
}

read.pgn <- function (filename,n=-1) {
	# collect results strings
	res=c()
	if (!file.exists(filename)) {
		stop(paste("Error: file",filename,
		 "does not exists!"))
	}
	fin = file(filename,'r')
	# our hit counter i
	i=0
	while(length((line=readLines(fin,n=1L)))>0) {
	    if (grepl('^\\[[Ff][Ee][Nn] +"',line)) {
			i = i + 1
			fenstr=gsub('.+"(.+)".+','\\1',line)
			#print(fenstr)
			res=c(res,fenstr)
			if (i == n) {
				break
			}
		}
	}
	close(fin)
	return(res)
}
