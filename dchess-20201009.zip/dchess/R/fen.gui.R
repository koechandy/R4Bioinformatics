GV=new.env()
GV$GuiImageFile=''
GV$GuiImageVar =tclVar()
GV$GuiTV=''
GuiImageCreate <- function () {
	# we need a few global vars without OO
	# don't use <<- here as this gives an error
	# cannot change value of locked binding for '.GuiImageFile'
	GV$GuiImageFile = paste(tempfile(),".png",sep="")
	png(GV$GuiImageFile,width=600,height=600)
	plot(1)
	dev.off()
	#gv['GuiImageVar'] = tclVar()
	tkimage.create('photo', GV$GuiImageVar, file = GV$GuiImageFile)
	#print(gv$GuiImageFile)
}
GuiOpenFile <- function (filename="") {
	if (filename == '') {
		filename = tclvalue(tkgetOpenFile(
			title ='Open file ...',
			filetypes = "{{PGN Files} {.pgn}}   
			             {{FEN Files} {.fen}}   
			             {{All Files} *}"))
     }
     # check and do something with filename
     if (filename != '') {
		 # use could have pressed escape or so
		 fens=read.pgn(filename)
		 # that would open a R window
		 GuiImage(fens[1])
		 # delete old entries
		 #for (child in tcl(.GuiTV,'children','')) {
		 #	 tkdelete(.GuiTV,child)
		 #}
		 for (fen in fens) {
			tkinsert(GV$GuiTV,'','end',values=c(fen))		
		 }
	 }
     return(filename)
}
GuiImage <- function (fenstr) {
	 #print(paste("GuiImageFile =",gv$GuiImageFile))
	 png(GV$GuiImageFile,width=600,height=600)
     plot(fen.new(fenstr))
	 dev.off()
	 tkimage.delete(GV$GuiImageVar)
	 tkimage.create('photo', GV$GuiImageVar, file = GV$GuiImageFile)
} 	
GuiExit <- function (tt) {
	res <- tkmessageBox(
		title = "Question ...", 
		message = "Really close the application?", icon = "question",
		type = "yesno")
	if (tclvalue(res)== "yes") {
		tkdestroy(tt)
	}
}
GuiAbout <- function () {
	tkmessageBox(
		title = "About ...", 
		message = "TkGui by Detlef Groth\nUniversity of Potsdam\n     2020", 
		icon = "info",
		type = "ok")
}
GuiTvClick <- function () {
	#print("clicked")
	idx=tclvalue(tcl(GV$GuiTV,'selection'))
	fen=tclvalue(tcl(GV$GuiTV,'item',idx,'-values'))
	GuiImage(fen)
}
GuiStart <- function (filename='') {
	# toplevel
	tt=tktoplevel()
	tkwm.title(tt,"Fen Viewer - D. Groth")
	GuiImageCreate()
	# standard menues
	topMenu<-tkmenu(tt,tearoff=FALSE)
	tkconfigure(tt,menu=topMenu)
	fileMenu<-tkmenu(topMenu, tearoff=FALSE)
    tkadd(topMenu, "cascade", label="File", 
           menu=fileMenu, underline=0)
	tkadd(fileMenu,"command",label="Open file ...",
	    command=function () GuiOpenFile(),underline=0)
	tkadd(fileMenu,"separator")    
    tkadd(fileMenu,"command",label="Exit",
		command=function() GuiExit(tt),     
		  underline=1)
    helpMenu<-tkmenu(topMenu, tearoff=FALSE)
    		  
    tkadd(topMenu, "cascade", label="Help", 
           menu=helpMenu, underline=0)
	tkadd(helpMenu,"command",label="About",
	    command=GuiAbout,underline=0)
	# mainframe with panedwindow
	mf=ttkframe(tt) # main application frame
	pw=ttkpanedwindow(mf,orient='horizontal')
	lw=ttktreeview(pw,columns=c('FEN'),show="headings")
	rw=ttklabel(pw,image=GV$GuiImageVar)
	tkadd(pw,lw)
	tkadd(pw,rw)
	tkpack(pw,side='top',fill='both',expand=TRUE)
	tkpack(mf,side='top',fill='both',expand=TRUE)
	# some global vars
	GV$GuiTV    = lw
	GV$GuiLabel = rw
	tkbind(GV$GuiTV,'<Button-1>',GuiTvClick)
	tkbind(GV$GuiTV,'<Return>',GuiTvClick)
	if (filename != '') {
		GuiOpenFile(filename)
	} else {
		GuiImage('r1bk3r/p2pBpNp/n4n2/1p1NP2P/6P1/3P4/P1P1K3/q5b1')
	}
	invisible(tt)
}
# the only public function
fen.gui = function (filename='') {
	GuiStart(filename)
}
