#!/usr/bin/env Rscript
# during development you can uncomment the next three comments
library(tcltk)
#.libPaths(c("~/PwR-labs/rlibs",.libPaths()))
library(dchess)
#source("dchess/R/dchess.R")

usage <- function () {
	cat("FenGui application by Detlef Groth, University of Potsdam\n")
	cat("Demonstration project for the course 'Programming with R'\n")
	cat("Usage: fengui.R [filename]\n")
	cat("       filename (optional) should be a PGN file with FEN strings\n")
}
main <- function () {
	args=commandArgs(trailingOnly=TRUE)
	if (length(args) == 0) {
		win=fen.gui()
		# mainloop, otherwise from Rscript app would close
		tkwait.window(win)
	} else {
		if (args[1] %in% c("-h","--help")) {
			usage()
		} else if (!file.exists(args[1])) {
			stop(paste("Error: file",args[1],"does not exists!"))
		} else {
			win=fen.gui(args[1])
			tkwait.window(win)
		}

	}
}
if (sys.nframe() == 0 & !interactive()) {
	main()
}
